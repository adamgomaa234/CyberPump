using System.ComponentModel.DataAnnotations;

namespace CyberPump.Models
{
    public class Gym
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string City { get; set; } = string.Empty;  // ADDED - Critical for filtering!

        [Required]
        public string Location { get; set; } = string.Empty;

        [Required]
        public string Timings { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        [Required]
        public decimal Price { get; set; }  // Changed from string to decimal

        [Range(0, 5)]
        public double Rating { get; set; }

        public string Features { get; set; } = string.Empty;

        public string ImageUrl { get; set; } = string.Empty;
    }
}