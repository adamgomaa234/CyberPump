using System.ComponentModel.DataAnnotations;

namespace CyberPump.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;  // Changed from Password

        [Range(1, 100)]
        public int Age { get; set; }  // Changed from string to int

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;  // Added
    }
}