﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Text.Json.Serialization;

namespace CyberPump.Models
{
    public class Meal
    {
        [Key]
        public int Id { get; set; }

        // --- RELATIONSHIP SETTINGS ---
        [Required]
        public int UserId { get; set; }  // Matches your session logic

        // [ForeignKey("UserId")]
        // public User User { get; set; }   // This works since you have User.cs!
        [ValidateNever]        // Tells the Validator: "Don't check this."
        [JsonIgnore]           // Tells the JSON converter: "Don't look for this in the input."
        public User? User { get; set; }  // Add the '?' to make it optional

        // --- MEAL DATA ---
        [Required]
        public DateTime Date { get; set; }

        [Required]
        [MaxLength(20)]
        public string MealType { get; set; } // breakfast, lunch, dinner

        [Required]
        [MaxLength(100)]
        public string FoodName { get; set; } // Matches JS "foodName"

        public int Calories { get; set; }

        // --- MACROS (With Fix for Warnings) ---
        [Column(TypeName = "decimal(18,2)")]
        public decimal Protein { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Carbs { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Fat { get; set; }    // Matches JS "fat"

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}