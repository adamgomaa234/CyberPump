﻿using Microsoft.EntityFrameworkCore;
using CyberPump.Models;

namespace CyberPump.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }

        // ADD THIS LINE:
        public DbSet<Gym> Gyms { get; set; }
        public DbSet<Meal> Meals { get; set; }
        public DbSet<Workout> Workouts { get; set; }
        
    }
}