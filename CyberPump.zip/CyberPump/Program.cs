using CyberPump.Data;
using CyberPump.Models; // Needed for the Gym model
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Database Connection
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

var app = builder.Build();

// --- FORCE SEED DATA (Runs every time app starts) ---
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    // 1. Ensure Database is Created
    context.Database.EnsureCreated();

    // 2. Check if Gyms exist. If NOT, add them.
    if (!context.Gyms.Any())
    {
        context.Gyms.AddRange(
            new Gym
            {
                Name = "Gold's Gym",
                City = "Cairo",
                Location = "Maadi, Degla",
                Rating = 4.8,
                Price = 50.00m,
                Timings = "6:00 AM - 12:00 AM",
                Description = "World famous gym with premium equipment.",
                Features = "AC, Sauna, Pool",
                ImageUrl = "https://images.unsplash.com/photo-1534438327276-14e5300c3a48"
            },
            new Gym
            {
                Name = "Alexandria Fitness",
                City = "Alexandria",
                Location = "San Stefano",
                Rating = 4.5,
                Price = 40.00m,
                Timings = "24 Hours",
                Description = "Train with a view of the sea.",
                Features = "AC, Wi-Fi, Cardio",
                ImageUrl = "https://images.unsplash.com/photo-1540497077202-7c8a336322b4"
            }
        );
        context.SaveChanges(); // Saves the data to SQL
    }
}
// --- END SEED DATA ---

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();

// Serve the website files
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();

app.Run();